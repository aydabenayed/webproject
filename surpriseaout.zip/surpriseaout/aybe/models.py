

from django.db import models
from django.contrib.auth.models import User

class Story(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # auteur de l’histoire
    title = models.CharField(max_length=100, verbose_name="عنوان")
    description = models.TextField(verbose_name="الوصف")
    date = models.DateField(verbose_name="التاريخ")
    image = models.ImageField(upload_to='stories/', blank=True, null=True, verbose_name="صورة")

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title} - {self.user.username}"
