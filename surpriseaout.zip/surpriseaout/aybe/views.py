from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import LoginForm

from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from .forms import LoginForm

def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')  # si déjà connecté, va au dashboard

    form = LoginForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.get_user()
        if user is not None:
            login(request, user)
            return redirect('dashboard')  # <-- ici la redirection après login

    return render(request, 'aybe/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    return render(request, 'aybe/dashboard.html')
from django.shortcuts import render

from django.contrib.auth.decorators import login_required
from .forms import StoryForm

@login_required
def story_create(request):
    if request.method == 'POST':
        form = StoryForm(request.POST, request.FILES)
        if form.is_valid():
            story = form.save(commit=False)
            story.user = request.user
            story.save()
            return redirect('dashboard')
    else:
        form = StoryForm()
    return render(request, 'aybe/story_form.html', {'form': form})
from .models import Story
from django.contrib.auth.decorators import login_required

from django.db.models import Q

@login_required
def story_list(request):
    query = request.GET.get('q', '')
    stories = Story.objects.filter(user=request.user)

    if query:
        stories = stories.filter(
            Q(title__icontains=query) | Q(description__icontains=query)
        )

    stories = stories.order_by('-date')

    return render(request, 'aybe/story_list.html', {
        'stories': stories,
        'query': query,
    })
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from .models import Story
from .forms import StoryForm

@login_required
def story_update(request, pk):
    story = get_object_or_404(Story, pk=pk, user=request.user)
    if request.method == 'POST':
        form = StoryForm(request.POST, request.FILES, instance=story)
        if form.is_valid():
            form.save()
            return redirect('story_list')
    else:
        form = StoryForm(instance=story)
    return render(request, 'aybe/story_form.html', {'form': form, 'edit': True})

@login_required
def story_delete(request, pk):
    story = get_object_or_404(Story, pk=pk, user=request.user)
    if request.method == 'POST':
        story.delete()
        return redirect('story_list')
    return render(request, 'aybe/story_confirm_delete.html', {'story': story})
from django.contrib.auth.decorators import login_required
from .models import Story

@login_required
def gallery_view(request):
    stories = Story.objects.filter(user=request.user).exclude(image='').order_by('-date')
    return render(request, 'aybe/gallery.html', {'stories': stories})
