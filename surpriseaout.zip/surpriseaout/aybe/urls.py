from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('story/add/', views.story_create, name='story_add'),
    path('stories/', views.story_list, name='story_list'),
    path('story/<int:pk>/edit/', views.story_update, name='story_edit'),
    path('story/<int:pk>/delete/', views.story_delete, name='story_delete'),
path('gallery/', views.gallery_view, name='gallery'),

]
